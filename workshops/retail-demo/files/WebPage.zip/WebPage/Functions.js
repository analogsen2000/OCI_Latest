//DEFINE STORES API REQUEST URL
//In the line below, replace the url in quotes with your 'stores' API URL from APEX
var stores_api_url = "https://tvruyw495v5qxgj-rdadw.adb.us-phoenix-1.oraclecloudapps.com/ords/DEVELOPER/sales/stores";

//DEFINE PREDICTION API REQUEST URL
//In the line below, replace the url in quotes with your 'prediction' API URL from APEX, deleting "{store_id}" from the end of the url
var prediction_api_url = "https://tvruyw495v5qxgj-rdadw.adb.us-phoenix-1.oraclecloudapps.com/ords/DEVELOPER/sales/newPrediction/";


//initializing global variables
var x, i, j, selElmnt, a, b, c;
var selectedStoreName;
var stores = [];
var storeNames = [];
var store_id;

function onLoad() {
    //initialize new REST API request
    var request = new XMLHttpRequest();

    //set the request parameters
    request.open("GET", stores_api_url);
    
    //send the request defined above
    request.send();

    //handle the response data
    request.onload = function () {
        var storeData = JSON.parse(this.response);

        var dropdown = document.getElementById("stores");

        //add all store options to dropdown
        for(var store in storeData.items) {
            stores.push(storeData.items[store]);
            storeNames.push(stores[store].store_address);
            var storeElement = document.createElement("option");
            storeElement.innerHTML = storeNames[store];
            storeElement.value = parseInt(store) + 1;
            dropdown.appendChild(storeElement);
        }

        console.log(stores);

        //select dropdown html element
        x = document.querySelectorAll(".custom-select");
        for (i = 0; i < x.length; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];

        //create a new div for each select element
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);

        //create div with dropdown options
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < selElmnt.length; j++) {
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;
            c.addEventListener("click", function(e) {
                //update select box when option is selected from dropdown
                var y, i, k, s, h;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                h = this.parentNode.previousSibling;
                for (i = 0; i < s.length; i++) {
                if (s.options[i].innerHTML == this.innerHTML) {
                    s.selectedIndex = i;
                    h.innerHTML = this.innerHTML;
                    y = this.parentNode.getElementsByClassName("same-as-selected");
                    for (k = 0; k < y.length; k++) {
                    y[k].removeAttribute("class");
                    }
                    this.setAttribute("class", "same-as-selected");
                    break;
                }
                }
                h.click();

                //update global variables with selected option's data
                var storeName = document.getElementById("storeTitle");
                storeName.innerHTML = h.innerHTML;
                selectedStoreName = h.innerHTML;
                var selectedTable = document.getElementById("inventoryTable");
                if(selectedTable.parentNode !== null) {
                    selectedTable.parentNode.removeChild(selectedTable);
                }
            });
            
            b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
            //close dropdown when a selection is made
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
            });
        }

        document.addEventListener("click", closeAllSelect);

    }
}



function closeAllSelect(elmnt) {
    //close dropdown
    var x, y, i, arrNo = [];
    x = document.getElementsByClassName("select-items");
    y = document.getElementsByClassName("select-selected");
    for (i = 0; i < y.length; i++) {
        if (elmnt == y[i]) {
        arrNo.push(i)
        } else {
        y[i].classList.remove("select-arrow-active");
        }
    }
    for (i = 0; i < x.length; i++) {
        if (arrNo.indexOf(i)) {
        x[i].classList.add("select-hide");
        }
    }
}


function addTable() {

    var storeProducts = [];

    //update store ID to selected store
    for(i=0; i<stores.length; i++) {
        if(selectedStoreName == stores[i].store_address) {
            store_id = stores[i].id;
        }
    }


    //define new REST API request
    var request = new XMLHttpRequest();

    //set the request parameters
    request.open("GET", prediction_api_url + store_id);

    //send the request defined above
    request.send();

    //handle the response data
    request.onload = function () {
        var storeProductData = JSON.parse(this.response);

        for(var product in storeProductData.items) {
            storeProducts.push(storeProductData.items[product]);
        }
        
        var productsArray = [];
        //add store's inventory to products array
        for(var product in storeProducts) {
            productsArray[product] = new Array(storeProducts[product].item_name, storeProducts[product].type, storeProducts[product].msrp, storeProducts[product].predicted_quantity_next_week);
        }


        var tableElement = document.getElementById("inventoryTable");

        var myTableDiv = document.getElementById("container");
        if(!tableElement) {
            //create inventory table for store
            var table = document.createElement('TABLE');
            table.id = "inventoryTable"
            var tableBody = document.createElement('TBODY');
            table.border = '1';
            table.appendChild(tableBody);

            table.style.borderColor = "rgb(193, 189, 188)";
            table.style.borderStyle = "double";

            var heading = new Array();
            heading[0] = "Product Name";
            heading[1] = "Type";
            heading[2] = "MSRP($)";
            heading[3] = "Predicted Sold Count for Upcoming Week";
            var tr = document.createElement('TR');
            tableBody.appendChild(tr);
            for(i=0; i<heading.length;i++) {
                var th = document.createElement('TH');
                th.width = '75';
                th.appendChild(document.createTextNode(heading[i]));
                tr.appendChild(th);
            }

            for(i=0; i<productsArray.length; i++) {
                var tr = document.createElement('TR');
                for (j=0; j<productsArray[i].length; j++) {
                    var td = document.createElement('TD');
                    td.appendChild(document.createTextNode(productsArray[i][j]));
                    tr.appendChild(td);
                }
                tableBody.appendChild(tr);
            }
            myTableDiv.appendChild(table);
        }
    }
}